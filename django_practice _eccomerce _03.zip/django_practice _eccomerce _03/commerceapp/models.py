from django.db import models

from django.db import models
from django.contrib.auth.models import User
class Profile(models.Model):
	user=models.OneToOneField(User, on_delete=models.CASCADE)
	mobile= models.CharField(max_length=12)


class ContactData(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    subject = models.CharField(max_length=200)
    message = models.TextField()

    def __str__(self):
        return self.name  # Or any other field you want to display

