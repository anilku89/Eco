from django.http import HttpResponse
from django.shortcuts import render
from django.shortcuts import render, redirect
from . models import Profile,ContactData
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required

def home(request):
    return render(request, 'index.html')
def main(request):
    return render(request, 'main.html')
def login_call(request):
    if request.method=='POST':
        username = request.POST['uname']
        pasw = request.POST['psw']
        currUser = authenticate(username= username,password=pasw)
        if currUser:
            login(request,currUser)
            print("Done!")
            return redirect('/main')
        else:
            return redirect('/signup')
    return render(request, 'loginpage.html')


def signup(request):
    if request.method=='POST':
        fullname = request.POST['fullname']
        mobile = request.POST['mobile'] 
        email = request.POST['email']
        psw = request.POST['psw']
        pswrepeat = request.POST['pswrepeat']
        fullname = request.POST['fullname']
        u = User(first_name = fullname, username = email, email=email, password=pswrepeat)
        u.save()
        p = Profile(user = u, mobile = mobile)
        p.save()
        print("Saved!")
        return redirect('/login')

    return render(request,'register.html')

def logout_call(request):
    logout(request)
    return redirect('/home')


def about(request):
    return render(request, 'about.html')
def product(request):
    return render(request, 'product.html')
def contact(request):
    if request.method=='POST':
        fullname = request.POST['name']
        email = request.POST['email']
        subject = request.POST['subject']
        message=request.POST['message']
        e = ContactData(name = fullname, email = email,subject=subject,message=message)
        e.save()
    
    return render(request, 'contact.html')
def testimonial(request):
    return render(request, 'testimonial.html')
def blog_list(request):
    return render(request, 'blog_list.html')

